//
//  ViewModelPong.swift
//  Virtual_Pong_WatchOS Watch App
//
//  Created by Aniello  on 24/02/23.
//

import Foundation
import Combine

class ViewModelPong: ObservableObject {
    private var userConnectivityPong: UserConnectivityPong
    
    var requests: AnyCancellable?
    var valueModelPong: PassthroughSubject<String, Never> = PassthroughSubject()
    
    @Published var colpo = "Paolo"
    
    init(){
        userConnectivityPong = UserConnectivityPong(modelUpdate: valueModelPong)
        userConnectivityPong.connect()
        print("sono connesso, ricevo update")
        requests = valueModelPong.sink {
            value in
            DispatchQueue.main.async{
                self.colpo = value
                }
            }
        }
    
    func sendMessage(key: String, value: Any){
        let message = [key: value]
        print("richiamo send message e mando ", message)
        userConnectivityPong.sendMessage(message: message)
    }
}
