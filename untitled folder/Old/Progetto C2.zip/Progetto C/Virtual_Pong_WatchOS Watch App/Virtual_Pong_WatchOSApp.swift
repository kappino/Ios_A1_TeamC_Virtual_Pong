//
//  Virtual_Pong_WatchOSApp.swift
//  Virtual_Pong_WatchOS Watch App
//
//  Created by Aniello  on 24/02/23.
//

import SwiftUI

@main
struct Virtual_Pong_WatchOS_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
