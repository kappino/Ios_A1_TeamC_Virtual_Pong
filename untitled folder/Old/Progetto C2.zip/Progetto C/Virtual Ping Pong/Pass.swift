//
//  Pass.swift
//  Virtual Ping Pong
//
//  Created by Crescenzo Esposito on 28/10/22.
//

import Foundation


class Pass: ObservableObject {
    @Published var join: Bool = false
    @Published var host: Bool = false
}
