//
//  Virtual_Ping_PongApp.swift
//  Virtual Ping Pong
//
//  Created by Crescenzo Esposito on 26/10/22.
//

import SwiftUI

@main
struct Virtual_Ping_PongApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
