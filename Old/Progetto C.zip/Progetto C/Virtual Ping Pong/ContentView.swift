//
//  MainView.swift
//  Virtual Ping Pong
//
//  Created by Crescenzo Esposito on 26/10/22.
//

import SwiftUI
import ParthenoKit

let rosso = "B82F1C"
let bianco = "FFECDD"
let sfondo = "47B98E"
var paddle = ""

struct ContentView: View {
    @StateObject private var viewModelPong: ViewModelPong = ViewModelPong()
    var body: some View {
        NavigationView {
            ZStack{
                Color(hex: sfondo).ignoresSafeArea(.all)
                
                VStack {
                    
                    LogoText(text: "Virtual\nPong")
                        
                    
                    Image("tennispaddles")
                        .aspectRatio(contentMode: .fit)
                    
//                    NavigationLink(destination: ConnectView()) {
//                        RoundedButton(name: "Connect")
//                    }
//                    NavigationLink (destination: TrainingView()) {
//                        RoundedButton(name: "Training")
//                    }
                    RoundedButton(name: viewModelPong.colpo)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}


