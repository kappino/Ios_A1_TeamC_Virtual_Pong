import SwiftUI
import HealthKit

struct ContentView: View {
    // Creazione dell'oggetto per la gestione dei dati dai sensori
    //    let motionManager = CMMotionManager()
    @StateObject private var viewModelPong: ViewModelPong = ViewModelPong()
    
    
    
    
    // Creazione dell'oggetto per la predizione di attività
    //    let activityClassifier = try? Pong_Test_2(configuration: MLModelConfiguration())
    
    let healthStore = HKHealthStore()
    @State var session:HKWorkoutSession?
    @State var builder:HKLiveWorkoutBuilder?
    let allTypes = Set([ HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)! , HKObjectType.quantityType(forIdentifier: .heartRate)!])
    private var rilevamento = Movimento()
    
    let config = HKWorkoutConfiguration()
    init() {
        config.activityType = .tableTennis
        config.locationType = .indoor
    }
    
    
    // Dichiarazione di un timer globale
    @State private var isShowingSecondView = false
    @State var currentActivity: String?
    @State var partita = false
    func requestAuth() {
        healthStore.requestAuthorization(toShare: [HKObjectType.workoutType()], read: allTypes) {
            (success, error) in
            if !success {
                print("Error!")
            }
        }
    }
    
    func stopSession() {
        if let session = session {
            session.stopActivity(with: Date())
            session.end()
            print("Ah")
            self.session = nil
            builder!.endCollection(withEnd: Date(), completion: {
                _, error in
            })
        }
        
    }
    
    
    var body: some View {
        
        GeometryReader{
            reader in
            ZStack {
                Image("BG")
                    .resizable()
                    .ignoresSafeArea(.all)
                    .aspectRatio(contentMode: .fill)
                    .frame(height: reader.size.height)
                
                VStack {
                    Image("log")
                        .resizable()
                        .frame(width: 65, height: 45)
                        .position(x:40 , y: -8)
                        .foregroundColor(.white)
                        .padding()
                    if (viewModelPong.partita == "false"){
                        Text("In attesa di connessione")
                    } else {
                        
                       Text("Partita iniziata")
                            .onAppear{partita = true}
                            .sheet(isPresented: $partita, content: {
                                InsertCodeView()
                            })
                    }
//                    Text("Attività fisica rilevata: \(currentActivity ?? "Nessuna")")
                    
                    
//                    Button(action: {
//                        // Gestione dell'azione del pulsante
//                        session = try? HKWorkoutSession.init(healthStore: self.healthStore, configuration: config)
//                        if let session = session {
//                            builder = session.associatedWorkoutBuilder()
//                            builder!.dataSource = HKLiveWorkoutDataSource(healthStore: self.healthStore, workoutConfiguration: config)
//                            session.startActivity(with: Date())
//                            builder!.beginCollection(withStart: Date(), completion: {
//                                _, error in
//                            })
//                        }
//                        rilevamento.startMotionUpdates()
//                    }) {
//                        Text("Play")
//                            .font(.system(size: 20, weight: .semibold, design: .default))
//
//                            .foregroundColor(.white)
//                    }
//                    .padding(10)
//
//                    Button(action: {
//                        rilevamento.stopMotionUpdates()
//                        stopSession()
//                    }) {
//                        Text("Ferma")
//                    }
                    
                }.onAppear{
                    requestAuth()
                }
            }
        }
    }
}
