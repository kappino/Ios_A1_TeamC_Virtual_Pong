//
//  SecondView.swift
//  Vpong Watch App
//
//  Created by Vincenzo Salzano on 01/03/23.
//

import SwiftUI

struct InsertCodeView: View {
    
    @State private var isShowingVibrationView = false
    
    @State var code1 = ""
    @State var code2 = ""
    @State var code3 = ""
    @State var code4 = ""
    
    var body: some View {
        ZStack {
            Image("Green")
                .resizable()
                .ignoresSafeArea(.all)
            VStack {
                Text("Inserire Codice:")
                    .font(.headline)
                    .padding()
                    .position(x: 101, y: 35)
                    .frame(width: 200, height: 30)
                
                HStack(spacing: 10) {
                    CodeTextField(text: $code1)
                    CodeTextField(text: $code2)
                    CodeTextField(text: $code3)
                    CodeTextField(text: $code4)
                }
                .padding()
                
                Button(action: {
                    if !code1.isEmpty && !code2.isEmpty && !code3.isEmpty && !code4.isEmpty {
                        // Gestione dell'azione del pulsante
                        isShowingVibrationView = true
                    }
                }) {
                    
                    Text("Avanti")
                        .font(.system(size: 20, weight: .semibold, design: .default))
                    
                        .foregroundColor(.white)
                }
                .padding(5)
                
                //Seconda schermata
                .sheet(isPresented: $isShowingVibrationView) {
                    VibrationView()
                    
                }
                .padding(5)
                .cornerRadius(250)
                
                .position(x: 91, y: 60)
                .frame(width: 183, height: 100)
            }
        }
    }
    struct CodeTextField: View {
        @Binding var text: String
        
        var body: some View {
            TextField("", text: $text)
                .position(x:18 ,y: 40)
                .frame(width: 35, height: 30)
        }
    }
}
