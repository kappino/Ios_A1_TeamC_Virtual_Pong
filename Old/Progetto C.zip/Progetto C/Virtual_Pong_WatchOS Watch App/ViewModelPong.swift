//
//  ViewModelPong.swift
//  Virtual_Pong_WatchOS Watch App
//
//  Created by Aniello  on 24/02/23.
//

import Foundation
import Combine

struct Value: Codable {
    let path: String
    let value: String
}

class ViewModelPong: ObservableObject {
    private var userConnectivityPong: UserConnectivityPong
    
    var requests: AnyCancellable?
    var valueModelPong: PassthroughSubject<Value, Never> = PassthroughSubject()
    
    @Published var colpo = "Paolo"
    @Published var partita = "false"
    init(){
        userConnectivityPong = UserConnectivityPong(modelUpdate: valueModelPong)
        userConnectivityPong.connect()
        print("sono connesso, ricevo update")
        requests = valueModelPong.sink {
            value in
            DispatchQueue.main.async{
                switch value.path {
                case "colpo":
                    self.colpo = value.value
                case "partita":
                    self.partita = value.value
                default:
                    print("Error")
                    
                }
                }
            }
        }
    
    func sendMessage(key: String, value: Any){
        let message = ["path": key, "value": value]
        print("richiamo send message e mando ", message)
        userConnectivityPong.sendMessage(message: message)
    }
}
